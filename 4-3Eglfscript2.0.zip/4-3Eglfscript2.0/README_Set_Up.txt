
EDIT: ONLY WORKS WITH WIDESCREEN MONITORS RN (16:9) RATIO. Working on fix for non-widescreen things

1) Must be using NOX on 1280x720 resolution on Windows 64-bit
	-Sometimes NOX doesnt actually use 1280x720 even if you select it and click apply. If this is the case, 
	apply a different res and change it back to 1280x720 
2) Know what "Corpse Dragging" is
3) Enter 4-3E and zoom out ALL THE WAY
4) You will be dragging using the first 2 units in either AR or RF category (MG cumming soon)
5) If you are doing an "Odd" # of runs your dragging in the very first slot must be full ammo+food. Vise versa for "Even" # runs.
6) Echelon 1 is used as resupply
7) Echelon 2 is the team you're leveling
8) In Echelon 2, the dragger will go in the "FIRST SLOT" from the "RIGHT"

-The script will handel repairing and resupply and restarting any expeditions
-If you're draggers clear the stage 2 slow PM me so I can increase the delay
-Stop the script by right clicking the script in your tray and click stop
	-Stopping the script is gay b/c this is basically GBF pokerbot but it controls your mouse more.
-Don't Modify the ______Default.jpg s
-If you have a potato or bad internet speed, then rip. PM me and maybe i'll impliment custom offsets
